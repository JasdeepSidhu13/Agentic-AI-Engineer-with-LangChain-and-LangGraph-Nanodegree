import json

import pytest

from src.analysis import run_deterministic_analysis
from src.data_loader import get_data_store
from src.schemas import AnalysisEvidence, DriverNarrative, NarrativeReport, Recommendation
from src.tools import (
    analyze_state_of_charge_patterns,
    compare_historical_vs_perfect_dispatch,
    compute_revenue_summary,
    identify_high_price_intervals,
    rank_gap_drivers,
)
from src.validator import validate_narrative


@pytest.fixture(autouse=True)
def reset_store():
    import src.data_loader as dl

    dl._STORE = None


def test_dataset_loads_one_week():
    store = get_data_store()
    assert store.summary["row_count"] == 672


def test_revenue_summary():
    data = json.loads(compute_revenue_summary.invoke({}))
    assert data["total_perfect_revenue_usd"] >= data["total_historical_revenue_usd"]
    assert data["total_gap_usd"] == pytest.approx(
        data["total_perfect_revenue_usd"] - data["total_historical_revenue_usd"], abs=0.01
    )


def test_high_price_intervals():
    data = json.loads(identify_high_price_intervals.invoke({"top_n": 5}))
    assert len(data["intervals"]) == 5


def test_dispatch_comparison():
    data = json.loads(compare_historical_vs_perfect_dispatch.invoke({"top_n": 5}))
    assert data["total_gap_in_top_intervals_usd"] > 0


def test_soc_patterns():
    data = json.loads(analyze_state_of_charge_patterns.invoke({}))
    assert "high_price_under_discharge_gap_usd" in data


def test_rank_gap_drivers():
    data = json.loads(rank_gap_drivers.invoke({}))
    assert len(data) >= 2
    assert data[0]["gap_usd"] >= data[1]["gap_usd"]


def test_deterministic_analysis_evidence_refs():
    evidence = run_deterministic_analysis()
    assert evidence.revenue_summary.total_gap_usd > 0
    assert len(evidence.ranked_drivers) == 4
    assert evidence.allowed_evidence_refs


def test_validator_accepts_grounded_narrative():
    evidence = run_deterministic_analysis()
    narrative = NarrativeReport(
        key_driver=DriverNarrative(
            name=evidence.ranked_drivers[0].name,
            explanation="Primary driver explanation.",
            evidence_refs=[f"ranked_drivers[0].gap_usd"],
        ),
        secondary_factor=DriverNarrative(
            name=evidence.ranked_drivers[1].name,
            explanation="Secondary factor explanation.",
            evidence_refs=[f"ranked_drivers[1].gap_usd"],
        ),
        recommendations=[
            Recommendation(
                action="Adjust pre-peak SOC target",
                rationale="SOC limited discharge during peaks.",
                expected_benefit="Reduce gap contribution from SOC constraints.",
                tradeoff="Less headroom for ancillary services.",
                evidence_refs=["soc_patterns.low_soc_during_high_price_gap_usd"],
            ),
            Recommendation(
                action="Add high-price discharge floor",
                rationale="Under-dispatch during top-quartile prices.",
                expected_benefit="Capture more spike revenue.",
                tradeoff="May increase cycling.",
                evidence_refs=["soc_patterns.high_price_under_discharge_gap_usd"],
            ),
        ],
    )
    result = validate_narrative(narrative, evidence)
    assert result.approved


def test_validator_rejects_wrong_driver_name():
    evidence = run_deterministic_analysis()
    narrative = NarrativeReport(
        key_driver=DriverNarrative(
            name="wrong_driver",
            explanation="Wrong.",
            evidence_refs=["revenue_summary.total_gap_usd"],
        ),
        secondary_factor=DriverNarrative(
            name=evidence.ranked_drivers[1].name,
            explanation="Secondary.",
            evidence_refs=["ranked_drivers[1].gap_usd"],
        ),
        recommendations=[
            Recommendation(
                action="A",
                rationale="R",
                expected_benefit="B",
                tradeoff="T",
                evidence_refs=["revenue_summary.total_gap_usd"],
            ),
            Recommendation(
                action="B",
                rationale="R",
                expected_benefit="B",
                tradeoff="T",
                evidence_refs=["revenue_summary.total_gap_usd"],
            ),
        ],
    )
    result = validate_narrative(narrative, evidence)
    assert not result.approved
    assert any("Key driver" in e for e in result.errors)
