from __future__ import annotations

import pandas as pd

from src.data_loader import get_data_store
from src.schemas import (
    AnalysisEvidence,
    GapDriver,
    HighPriceInterval,
    IntervalGap,
    RevenueSummary,
    SocPatterns,
)


def _add_gap_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["revenue_gap_usd"] = df["perfect_revenue_usd"] - df["historical_revenue_usd"]
    df["power_gap_mw"] = df["perfect_power_mw"] - df["historical_power_mw"]
    return df


def _compute_revenue_summary(df: pd.DataFrame) -> RevenueSummary:
    historical = round(float(df["historical_revenue_usd"].sum()), 2)
    perfect = round(float(df["perfect_revenue_usd"].sum()), 2)
    gap = round(perfect - historical, 2)
    gap_pct = round(gap / perfect * 100, 2) if perfect else 0.0
    return RevenueSummary(
        total_historical_revenue_usd=historical,
        total_perfect_revenue_usd=perfect,
        total_gap_usd=gap,
        gap_pct_of_perfect=gap_pct,
        interval_count=len(df),
    )


def _identify_high_price_intervals(df: pd.DataFrame, top_n: int = 10) -> list[HighPriceInterval]:
    top = df.nlargest(top_n, "market_price_usd_mwh")
    intervals = []
    for _, row in top.iterrows():
        hist = float(row["historical_power_mw"])
        perf = float(row["perfect_power_mw"])
        intervals.append(
            HighPriceInterval(
                timestamp=str(row["timestamp"]),
                market_price_usd_mwh=round(float(row["market_price_usd_mwh"]), 2),
                historical_power_mw=round(hist, 2),
                perfect_power_mw=round(perf, 2),
                revenue_gap_usd=round(float(row["revenue_gap_usd"]), 2),
                missed_discharge=hist < perf,
            )
        )
    return intervals


def _compare_dispatch(df: pd.DataFrame, top_n: int = 10) -> list[IntervalGap]:
    worst = df.nlargest(top_n, "revenue_gap_usd")
    rows = []
    for _, row in worst.iterrows():
        rows.append(
            IntervalGap(
                timestamp=str(row["timestamp"]),
                market_price_usd_mwh=round(float(row["market_price_usd_mwh"]), 2),
                historical_power_mw=round(float(row["historical_power_mw"]), 2),
                perfect_power_mw=round(float(row["perfect_power_mw"]), 2),
                historical_revenue_usd=round(float(row["historical_revenue_usd"]), 2),
                perfect_revenue_usd=round(float(row["perfect_revenue_usd"]), 2),
                revenue_gap_usd=round(float(row["revenue_gap_usd"]), 2),
            )
        )
    return rows


def _analyze_soc_patterns(df: pd.DataFrame) -> SocPatterns:
    price_threshold = float(df["market_price_usd_mwh"].quantile(0.75))
    high_price = df[df["market_price_usd_mwh"] >= price_threshold]
    low_soc_high_price = high_price[high_price["state_of_charge_pct"] < 30]
    under_discharge = high_price[high_price["historical_power_mw"] < high_price["perfect_power_mw"]]
    return SocPatterns(
        high_price_threshold_usd_mwh=round(price_threshold, 2),
        high_price_interval_count=len(high_price),
        high_price_under_discharge_count=len(under_discharge),
        high_price_under_discharge_gap_usd=round(float(under_discharge["revenue_gap_usd"].sum()), 2),
        low_soc_during_high_price_count=len(low_soc_high_price),
        low_soc_during_high_price_gap_usd=round(float(low_soc_high_price["revenue_gap_usd"].sum()), 2),
        avg_soc_during_high_price=round(float(high_price["state_of_charge_pct"].mean()), 2),
        avg_soc_overall=round(float(df["state_of_charge_pct"].mean()), 2),
    )


def _rank_gap_drivers(df: pd.DataFrame, total_gap: float) -> list[GapDriver]:
    price_threshold = float(df["market_price_usd_mwh"].quantile(0.75))
    high_price = df[df["market_price_usd_mwh"] >= price_threshold]

    under_discharge = high_price[high_price["historical_power_mw"] < high_price["perfect_power_mw"]]
    wrong_direction = df[(df["perfect_power_mw"] > 5) & (df["historical_power_mw"] < 0)]
    low_soc = high_price[high_price["state_of_charge_pct"] < 30]
    missed_charge = df[(df["perfect_power_mw"] < -5) & (df["historical_power_mw"] > df["perfect_power_mw"])]

    candidates = [
        GapDriver(
            name="under_discharge_during_high_prices",
            gap_usd=round(float(under_discharge["revenue_gap_usd"].sum()), 2),
            pct_of_total_gap=0.0,
            interval_count=len(under_discharge),
            description="Historical dispatch below perfect during top-quartile price intervals",
        ),
        GapDriver(
            name="wrong_direction_dispatch",
            gap_usd=round(float(wrong_direction["revenue_gap_usd"].sum()), 2),
            pct_of_total_gap=0.0,
            interval_count=len(wrong_direction),
            description="Historical charged while perfect foresight discharged",
        ),
        GapDriver(
            name="low_soc_during_high_prices",
            gap_usd=round(float(low_soc["revenue_gap_usd"].sum()), 2),
            pct_of_total_gap=0.0,
            interval_count=len(low_soc),
            description="Low SOC (<30%) during high-price intervals limited discharge",
        ),
        GapDriver(
            name="missed_low_price_charging",
            gap_usd=round(float(missed_charge["revenue_gap_usd"].sum()), 2),
            pct_of_total_gap=0.0,
            interval_count=len(missed_charge),
            description="Historical under-charged relative to perfect during low-price windows",
        ),
    ]

    for driver in candidates:
        driver.pct_of_total_gap = round(
            driver.gap_usd / total_gap * 100 if total_gap else 0.0, 2
        )

    return sorted(candidates, key=lambda d: d.gap_usd, reverse=True)


def run_deterministic_analysis(top_n: int = 10) -> AnalysisEvidence:
    """Run all analysis tools deterministically — no LLM involved."""
    df = _add_gap_columns(get_data_store().df)
    revenue = _compute_revenue_summary(df)
    drivers = _rank_gap_drivers(df, revenue.total_gap_usd)

    evidence = AnalysisEvidence(
        revenue_summary=revenue,
        high_price_intervals=_identify_high_price_intervals(df, top_n),
        largest_gap_intervals=_compare_dispatch(df, top_n),
        soc_patterns=_analyze_soc_patterns(df),
        ranked_drivers=drivers,
    )
    evidence.allowed_evidence_refs = _build_evidence_refs(evidence)
    return evidence


def _build_evidence_refs(evidence: AnalysisEvidence) -> list[str]:
    refs = [
        "revenue_summary.total_historical_revenue_usd",
        "revenue_summary.total_perfect_revenue_usd",
        "revenue_summary.total_gap_usd",
        "revenue_summary.gap_pct_of_perfect",
        "soc_patterns.high_price_under_discharge_gap_usd",
        "soc_patterns.low_soc_during_high_price_gap_usd",
        "soc_patterns.high_price_threshold_usd_mwh",
    ]
    for i, driver in enumerate(evidence.ranked_drivers):
        refs.append(f"ranked_drivers[{i}].gap_usd")
        refs.append(f"ranked_drivers[{i}].name")
        refs.append(f"ranked_drivers[{i}].interval_count")
    for i in range(min(3, len(evidence.largest_gap_intervals))):
        refs.append(f"largest_gap_intervals[{i}].timestamp")
        refs.append(f"largest_gap_intervals[{i}].revenue_gap_usd")
    return refs
