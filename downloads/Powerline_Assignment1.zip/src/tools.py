from __future__ import annotations

import json

from langchain_core.tools import tool

from src.analysis import run_deterministic_analysis


@tool
def compute_revenue_summary() -> str:
    """Compute total historical revenue, total perfect revenue, and the performance gap."""
    evidence = run_deterministic_analysis()
    return json.dumps(evidence.revenue_summary.model_dump())


@tool
def identify_high_price_intervals(top_n: int = 10) -> str:
    """Return the highest-price intervals and whether historical dispatch captured the opportunity."""
    evidence = run_deterministic_analysis()
    intervals = evidence.high_price_intervals[:top_n]
    missed = sum(1 for i in intervals if i.missed_discharge)
    return json.dumps(
        {
            "top_n": top_n,
            "intervals": [i.model_dump() for i in intervals],
            "missed_discharge_count": missed,
        }
    )


@tool
def compare_historical_vs_perfect_dispatch(top_n: int = 10) -> str:
    """Compare historical and perfect dispatch for the intervals with the largest revenue gap."""
    evidence = run_deterministic_analysis()
    intervals = evidence.largest_gap_intervals[:top_n]
    total = round(sum(i.revenue_gap_usd for i in intervals), 2)
    return json.dumps(
        {
            "top_n": top_n,
            "largest_gap_intervals": [i.model_dump() for i in intervals],
            "total_gap_in_top_intervals_usd": total,
        }
    )


@tool
def analyze_state_of_charge_patterns() -> str:
    """Analyze SOC patterns during high-price periods and low-SOC constraints on discharge."""
    evidence = run_deterministic_analysis()
    return json.dumps(evidence.soc_patterns.model_dump())


@tool
def rank_gap_drivers() -> str:
    """Rank the primary drivers of the performance gap by total revenue impact."""
    evidence = run_deterministic_analysis()
    return json.dumps([d.model_dump() for d in evidence.ranked_drivers])


@tool
def get_dataset_info() -> str:
    """Return dataset metadata (time range, interval count, columns)."""
    from src.data_loader import get_data_store

    return json.dumps(get_data_store().summary)


ANALYSIS_TOOLS = [
    compute_revenue_summary,
    identify_high_price_intervals,
    compare_historical_vs_perfect_dispatch,
    analyze_state_of_charge_patterns,
    rank_gap_drivers,
    get_dataset_info,
]
