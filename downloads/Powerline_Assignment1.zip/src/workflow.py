from __future__ import annotations

import json
import operator
from typing import Annotated, Optional

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.runnables import RunnableConfig
from langgraph.graph import END, StateGraph
from typing_extensions import TypedDict

from src.analysis import run_deterministic_analysis
from src.report import format_markdown_report
from src.schemas import AnalysisEvidence, NarrativeReport
from src.validator import validate_narrative

MAX_RETRIES = 2


class WorkflowState(TypedDict):
    user_prompt: str
    evidence: Optional[dict]
    narrative: Optional[dict]
    validation_errors: Annotated[list[str], operator.add]
    retry_count: int
    final_report: str


SYNTHESIS_PROMPT = """You are a battery trading decision-support agent for Powerline.

You will receive deterministic analysis evidence as JSON. Write narrative ONLY.
Do NOT invent or recalculate numbers.

Rules:
1. key_driver.name MUST be exactly: {key_driver_name}
2. secondary_factor.name MUST be exactly: {secondary_driver_name}
3. evidence_refs MUST be chosen ONLY from allowed_evidence_refs (copy exactly)
4. When stating dollar amounts in expected_benefit, use values from the evidence JSON
5. Provide exactly 2 recommendations with distinct actions
6. Be specific and practical for a battery trader

Allowed evidence refs:
{allowed_refs}

Evidence JSON:
{evidence_json}
{feedback_section}
"""


def analyze_node(state: WorkflowState, config: RunnableConfig) -> WorkflowState:
    evidence = run_deterministic_analysis()
    return {"evidence": evidence.model_dump(), "validation_errors": []}


def synthesize_node(state: WorkflowState, config: RunnableConfig) -> WorkflowState:
    llm = config["configurable"]["llm"]
    evidence = AnalysisEvidence.model_validate(state["evidence"])
    key_driver = evidence.ranked_drivers[0].name
    secondary = evidence.ranked_drivers[1].name if len(evidence.ranked_drivers) > 1 else key_driver

    feedback_section = ""
    prior_errors = state.get("validation_errors") or []
    if prior_errors:
        feedback_section = (
            "\n\nPrevious attempt failed validation:\n"
            + "\n".join(f"- {e}" for e in prior_errors)
            + "\nFix these issues."
        )

    prompt = SYNTHESIS_PROMPT.format(
        key_driver_name=key_driver,
        secondary_driver_name=secondary,
        allowed_refs=json.dumps(evidence.allowed_evidence_refs, indent=2),
        evidence_json=json.dumps(evidence.model_dump(), indent=2, default=str),
        feedback_section=feedback_section,
    )

    structured_llm = llm.with_structured_output(NarrativeReport)
    narrative: NarrativeReport = structured_llm.invoke(
        [
            SystemMessage(content=prompt),
            HumanMessage(content=state["user_prompt"]),
        ]
    )
    return {"narrative": narrative.model_dump()}


def validate_node(state: WorkflowState, config: RunnableConfig) -> WorkflowState:
    evidence = AnalysisEvidence.model_validate(state["evidence"])
    narrative = NarrativeReport.model_validate(state["narrative"])
    result = validate_narrative(narrative, evidence)

    if result.approved:
        markdown = format_markdown_report(evidence, narrative, state["user_prompt"])
        return {"final_report": markdown, "validation_errors": []}

    return {
        "validation_errors": result.errors,
        "retry_count": state.get("retry_count", 0) + 1,
    }


def finalize_node(state: WorkflowState, config: RunnableConfig) -> WorkflowState:
    evidence = AnalysisEvidence.model_validate(state["evidence"])
    narrative = NarrativeReport.model_validate(state["narrative"])
    markdown = format_markdown_report(evidence, narrative, state["user_prompt"])
    errors = state.get("validation_errors") or []
    if errors:
        markdown += (
            "\n\n> **Note:** Validation did not fully pass after retries. "
            "Performance gap figures remain tool-grounded; review narrative sections.\n"
            f"> Errors: {'; '.join(errors)}"
        )
    return {"final_report": markdown}


def route_after_validate(state: WorkflowState) -> str:
    if state.get("final_report"):
        return "finish"
    if state.get("retry_count", 0) <= MAX_RETRIES:
        return "synthesize"
    return "finalize"


def build_workflow():
    graph = StateGraph(WorkflowState)
    graph.add_node("analyze", analyze_node)
    graph.add_node("synthesize", synthesize_node)
    graph.add_node("validate", validate_node)
    graph.add_node("finalize", finalize_node)

    graph.set_entry_point("analyze")
    graph.add_edge("analyze", "synthesize")
    graph.add_edge("synthesize", "validate")
    graph.add_conditional_edges(
        "validate",
        route_after_validate,
        {"finish": END, "synthesize": "synthesize", "finalize": "finalize"},
    )
    graph.add_edge("finalize", END)
    return graph.compile()
