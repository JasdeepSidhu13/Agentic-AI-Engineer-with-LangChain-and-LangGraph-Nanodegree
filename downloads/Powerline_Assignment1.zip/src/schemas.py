from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator


class RevenueSummary(BaseModel):
    total_historical_revenue_usd: float
    total_perfect_revenue_usd: float
    total_gap_usd: float
    gap_pct_of_perfect: float
    interval_count: int


class IntervalGap(BaseModel):
    timestamp: str
    market_price_usd_mwh: float
    historical_power_mw: float
    perfect_power_mw: float
    historical_revenue_usd: float
    perfect_revenue_usd: float
    revenue_gap_usd: float


class HighPriceInterval(BaseModel):
    timestamp: str
    market_price_usd_mwh: float
    historical_power_mw: float
    perfect_power_mw: float
    revenue_gap_usd: float
    missed_discharge: bool


class SocPatterns(BaseModel):
    high_price_threshold_usd_mwh: float
    high_price_interval_count: int
    high_price_under_discharge_count: int
    high_price_under_discharge_gap_usd: float
    low_soc_during_high_price_count: int
    low_soc_during_high_price_gap_usd: float
    avg_soc_during_high_price: float
    avg_soc_overall: float


class GapDriver(BaseModel):
    name: Literal[
        "under_discharge_during_high_prices",
        "wrong_direction_dispatch",
        "low_soc_during_high_prices",
        "missed_low_price_charging",
    ]
    gap_usd: float
    pct_of_total_gap: float
    interval_count: int
    description: str


class AnalysisEvidence(BaseModel):
    """Deterministic tool outputs — single source of truth for all numbers."""

    revenue_summary: RevenueSummary
    high_price_intervals: list[HighPriceInterval]
    largest_gap_intervals: list[IntervalGap]
    soc_patterns: SocPatterns
    ranked_drivers: list[GapDriver]
    allowed_evidence_refs: list[str] = Field(default_factory=list)


class DriverNarrative(BaseModel):
    name: str
    explanation: str
    evidence_refs: list[str] = Field(min_length=1)


class Recommendation(BaseModel):
    action: str
    rationale: str
    expected_benefit: str
    tradeoff: str
    evidence_refs: list[str] = Field(min_length=1)


class NarrativeReport(BaseModel):
    """LLM-generated narrative only — numbers come from AnalysisEvidence."""

    key_driver: DriverNarrative
    secondary_factor: DriverNarrative
    recommendations: list[Recommendation] = Field(min_length=2, max_length=2)

    @field_validator("recommendations")
    @classmethod
    def distinct_actions(cls, value: list[Recommendation]) -> list[Recommendation]:
        actions = [r.action.strip().lower() for r in value]
        if len(set(actions)) < len(actions):
            raise ValueError("Recommendations must have distinct actions")
        return value


class ValidationResult(BaseModel):
    approved: bool
    errors: list[str] = Field(default_factory=list)
