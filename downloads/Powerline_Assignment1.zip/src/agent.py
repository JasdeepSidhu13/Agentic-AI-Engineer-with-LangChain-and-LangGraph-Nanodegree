from __future__ import annotations

import os

from langchain_openai import ChatOpenAI

from src.workflow import build_workflow


def get_llm(model: str | None = None) -> ChatOpenAI:
    return ChatOpenAI(
        model=model or os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
        temperature=0,
        api_key=os.getenv("OPENAI_API_KEY"),
    )


def run_analysis(user_prompt: str, model: str | None = None) -> str:
    """Run v2 pipeline: deterministic analysis → LLM narrative → validation."""
    app = build_workflow()
    result = app.invoke(
        {
            "user_prompt": user_prompt,
            "evidence": None,
            "narrative": None,
            "validation_errors": [],
            "retry_count": 0,
            "final_report": "",
        },
        config={"configurable": {"llm": get_llm(model)}},
    )
    return result["final_report"]
