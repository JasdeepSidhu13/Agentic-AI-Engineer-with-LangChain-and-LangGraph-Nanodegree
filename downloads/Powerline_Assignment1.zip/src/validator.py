from __future__ import annotations

import re

from src.schemas import AnalysisEvidence, NarrativeReport, ValidationResult


def _resolve_ref(evidence: AnalysisEvidence, ref: str):
    """Resolve dotted/bracket evidence reference against the evidence model."""
    current = evidence
    for part in ref.replace("]", "").split("."):
        if "[" in part:
            name, index_str = part.split("[")
            current = getattr(current, name)[int(index_str)]
        else:
            current = getattr(current, part)
    return current


def validate_narrative(
    narrative: NarrativeReport,
    evidence: AnalysisEvidence,
    *,
    require_driver_names: bool = True,
) -> ValidationResult:
    errors: list[str] = []

    if require_driver_names and evidence.ranked_drivers:
        expected_key = evidence.ranked_drivers[0].name
        expected_secondary = evidence.ranked_drivers[1].name if len(evidence.ranked_drivers) > 1 else None
        if narrative.key_driver.name != expected_key:
            errors.append(
                f"Key driver must be '{expected_key}', got '{narrative.key_driver.name}'"
            )
        if expected_secondary and narrative.secondary_factor.name != expected_secondary:
            errors.append(
                f"Secondary factor must be '{expected_secondary}', "
                f"got '{narrative.secondary_factor.name}'"
            )

    allowed = set(evidence.allowed_evidence_refs)
    for section, label in [
        (narrative.key_driver, "key_driver"),
        (narrative.secondary_factor, "secondary_factor"),
    ]:
        for ref in section.evidence_refs:
            if ref not in allowed:
                errors.append(f"{label} references unknown evidence ref: {ref}")
            else:
                try:
                    _resolve_ref(evidence, ref)
                except (AttributeError, IndexError, KeyError):
                    errors.append(f"{label} references invalid evidence ref: {ref}")

    for idx, rec in enumerate(narrative.recommendations):
        if not rec.evidence_refs:
            errors.append(f"Recommendation {idx + 1} missing evidence_refs")
        for ref in rec.evidence_refs:
            if ref not in allowed:
                errors.append(f"Recommendation {idx + 1} references unknown evidence ref: {ref}")

        # Flag suspicious invented dollar amounts not present in evidence text
        dollar_amounts = re.findall(r"\$[\d,]+(?:\.\d+)?", rec.expected_benefit)
        evidence_values = {
            str(v)
            for v in [
                evidence.revenue_summary.total_gap_usd,
                evidence.ranked_drivers[0].gap_usd if evidence.ranked_drivers else None,
                evidence.soc_patterns.high_price_under_discharge_gap_usd,
            ]
            if v is not None
        }
        for amount in dollar_amounts:
            numeric = amount.replace("$", "").replace(",", "")
            if not any(numeric in ev or ev in numeric for ev in evidence_values):
                errors.append(
                    f"Recommendation {idx + 1} expected_benefit contains unverified amount: {amount}"
                )

    return ValidationResult(approved=len(errors) == 0, errors=errors)
