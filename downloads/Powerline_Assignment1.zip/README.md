# Powerline Battery Performance Agent (v2)

LLM-powered agent that analyzes one week of battery interval data, compares **historical operation** vs **perfect foresight**, and produces actionable trading recommendations.

**v2 improvements:** deterministic tool execution, Pydantic schemas, programmatic driver ranking, and a validation gate before returning the report.

## How to Run

```bash
cd Powerline_Assignment1
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp example.env .env        # add OPENAI_API_KEY
python main.py
```

### Modes

```bash
# Full v2 pipeline (deterministic tools → LLM narrative → validation)
python main.py

# Deterministic only — no OpenAI key required
python main.py --dry-run

# Print raw evidence JSON from tools
python main.py --evidence

# Custom dataset
python main.py --data path/to/data.csv
```

Run tests:

```bash
python -m pytest tests/ -q
```

## v2 Architecture

```text
User prompt
    ↓
[1] Deterministic Analysis (Python, no LLM)
    → revenue summary, gap intervals, SOC patterns, ranked drivers
    ↓
[2] LLM Synthesis (structured Pydantic output)
    → explanations + 2 recommendations (narrative only)
    ↓
[3] Validation Gate
    → driver names match ranked evidence
    → evidence_refs are valid
    → retry up to 2x if fail
    ↓
Final report (numbers from tools, narrative from LLM)
```

See [architecture.md](architecture.md) for details.

## Why v2 Is More Reliable

| v1 weakness | v2 fix |
|-------------|--------|
| LLM could skip tools | All tools run deterministically first |
| LLM could invent numbers | Performance gap filled from tool output only |
| Driver chosen by LLM | Top 2 drivers ranked in code |
| No output validation | Pydantic schema + validator gate with retry |
| Free-form markdown | Structured `NarrativeReport` model |

## Project Structure

```text
Powerline_Assignment1/
├── main.py
├── README.md
├── architecture.md
├── example_output.md
├── data/data.csv
├── src/
│   ├── analysis.py      # Deterministic tool logic + driver ranking
│   ├── schemas.py       # Pydantic models
│   ├── workflow.py      # LangGraph: analyze → synthesize → validate
│   ├── validator.py     # Grounding checks
│   ├── report.py        # Markdown formatter
│   ├── agent.py         # Entry point
│   ├── tools.py         # LangChain tool wrappers (optional/debug)
│   └── data_loader.py
└── tests/
```

## Generalization

Column aliases in `data_loader.py` normalize common CSV naming variations. Semantic assumptions (sign conventions, revenue consistency) are documented in `architecture.md`.

## Author

Jasdeep Sidhu
