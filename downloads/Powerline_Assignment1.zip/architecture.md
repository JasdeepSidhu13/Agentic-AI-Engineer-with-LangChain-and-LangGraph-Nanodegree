# Architecture — Powerline Battery Performance Agent v2

## Design Principle

**Tools compute. Code ranks. LLM narrates. Validator gates.**

The LLM never calculates metrics and never selects which driver is primary — it only explains pre-computed evidence.

## Pipeline

```mermaid
graph TD
    START([User Prompt]) --> A[analyze_node<br/>Deterministic Python]
    A --> S[synthesize_node<br/>LLM + Pydantic]
    S --> V[validate_node<br/>Grounding checks]
    V -->|approved| END([Markdown Report])
    V -->|fail, retries left| S
    V -->|fail, max retries| F[finalize_node<br/>Best-effort + disclaimer]
    F --> END
```

## Layer 1: Deterministic Analysis (`analysis.py`)

Runs on every request, before any LLM call:

| Function | Output |
|----------|--------|
| Revenue summary | Historical, perfect, gap ($) |
| High-price intervals | Top-N spikes + missed discharge flags |
| Dispatch comparison | Largest gap intervals |
| SOC patterns | High-price SOC constraints |
| **Driver ranking** | 4 gap drivers sorted by $ impact |

### Ranked Drivers (computed in code)

1. `under_discharge_during_high_prices`
2. `wrong_direction_dispatch` — charged when perfect discharged
3. `low_soc_during_high_prices`
4. `missed_low_price_charging`

The top 2 become key driver and secondary factor — the LLM cannot override this.

## Layer 2: Pydantic Schemas (`schemas.py`)

| Model | Purpose |
|-------|---------|
| `AnalysisEvidence` | All numeric tool outputs |
| `GapDriver` | Ranked driver with gap_usd, pct, interval_count |
| `NarrativeReport` | LLM output: explanations + 2 recommendations |
| `ValidationResult` | Pass/fail + error list |

## Layer 3: LLM Synthesis (`workflow.py`)

- Receives evidence JSON + pre-assigned driver names
- Must use `with_structured_output(NarrativeReport)`
- Cannot change performance gap numbers (injected in `report.py`)
- Must cite `evidence_refs` from allowed list

## Layer 4: Validation Gate (`validator.py`)

Checks before returning:

1. `key_driver.name` matches `ranked_drivers[0].name`
2. `secondary_factor.name` matches `ranked_drivers[1].name`
3. All `evidence_refs` exist in `allowed_evidence_refs`
4. Recommendations have distinct actions
5. Dollar amounts in `expected_benefit` match evidence values

Failed validation → retry synthesis with error feedback (max 2 retries).

## Remaining Limitations

| Limitation | Mitigation path |
|------------|-----------------|
| Same-schema, different semantics | Add `validate_revenue_consistency()` on load |
| Fixed thresholds (P75, SOC<30) | Make configurable or data-driven |
| LLM narrative can still be vague | Tighten prompts; add minimum evidence ref count |
| Validator doesn't catch all hallucinations | Template-fill recommendations from driver templates |

## v1 → v2 Summary

```text
v1: User → ReAct Agent (may skip tools) → free-form text
v2: User → Tools (always) → Structured LLM → Validator → report
```
