#!/usr/bin/env python3
"""Powerline take-home: LLM agent for battery performance gap analysis."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from dotenv import load_dotenv

from src.agent import run_analysis
from src.analysis import run_deterministic_analysis
from src.data_loader import get_data_store
from src.report import format_markdown_report
from src.schemas import DriverNarrative, NarrativeReport, Recommendation

DEFAULT_PROMPT = (
    "Analyze this week's battery performance. Quantify the gap between historical "
    "and perfect foresight operation, identify the key driver and a secondary "
    "contributing factor, and give me two actionable recommendations."
)


def run_dry_analysis(user_prompt: str) -> str:
    """Deterministic-only mode: tools + driver ranking, no LLM narrative."""
    evidence = run_deterministic_analysis()
    drivers = evidence.ranked_drivers
    narrative = NarrativeReport(
        key_driver=DriverNarrative(
            name=drivers[0].name,
            explanation=drivers[0].description,
            evidence_refs=["ranked_drivers[0].gap_usd", "ranked_drivers[0].interval_count"],
        ),
        secondary_factor=DriverNarrative(
            name=drivers[1].name,
            explanation=drivers[1].description,
            evidence_refs=["ranked_drivers[1].gap_usd", "ranked_drivers[1].interval_count"],
        ),
        recommendations=[
            Recommendation(
                action="Review dispatch during top-quartile price intervals",
                rationale=f"Primary gap driver: {drivers[0].name}",
                expected_benefit=f"Addresses ${drivers[0].gap_usd:,.2f} of the total gap",
                tradeoff="Requires tighter coordination with bidding rules",
                evidence_refs=["ranked_drivers[0].gap_usd"],
            ),
            Recommendation(
                action="Evaluate SOC targets ahead of peak price windows",
                rationale=f"Secondary factor: {drivers[1].name}",
                expected_benefit=f"Targets ${drivers[1].gap_usd:,.2f} in gap contribution",
                tradeoff="May reduce flexibility for ancillary services",
                evidence_refs=["ranked_drivers[1].gap_usd"],
            ),
        ],
    )
    return format_markdown_report(evidence, narrative, user_prompt)


def main() -> None:
    load_dotenv()
    parser = argparse.ArgumentParser(description="Powerline battery performance analysis agent")
    parser.add_argument("--data", type=Path, default=None, help="Path to CSV dataset")
    parser.add_argument("--prompt", type=str, default=DEFAULT_PROMPT, help="Analysis prompt")
    parser.add_argument("--output", type=Path, default=None, help="Save report to file")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run deterministic tools only (no OpenAI call)",
    )
    parser.add_argument(
        "--evidence",
        action="store_true",
        help="Print raw deterministic evidence JSON",
    )
    args = parser.parse_args()

    store = get_data_store(args.data)
    print(
        f"Loaded {store.summary['row_count']} intervals "
        f"({store.summary['time_min']} → {store.summary['time_max']})\n"
    )

    if args.evidence:
        evidence = run_deterministic_analysis()
        print(json.dumps(evidence.model_dump(), indent=2, default=str))
        return

    if args.dry_run:
        print("Running deterministic analysis (dry-run)...\n")
        report = run_dry_analysis(args.prompt)
    else:
        if not os.getenv("OPENAI_API_KEY"):
            raise SystemExit("Error: Set OPENAI_API_KEY in .env (see example.env), or use --dry-run")
        print("Running v2 pipeline (deterministic tools → LLM narrative → validation)...\n")
        report = run_analysis(args.prompt)

    if args.output:
        args.output.write_text(report + "\n")
        print(f"Report saved to {args.output}\n")

    print(report)


if __name__ == "__main__":
    main()
